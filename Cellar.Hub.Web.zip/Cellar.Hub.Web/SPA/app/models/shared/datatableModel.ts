﻿export class DatatableModel
{
    public isChanged: boolean;

    public currentPage: number;
    public sortField: string;
    public sortOrder: number;
    public multiSortMeta: any;
    public currentRows: number;

    public filters: any;

}