
export class CellarSenzorSettings {
    WifiSSID: string;
    WifiPassword: string;

    MQTTUrl: string;
    MQTTTopic: string;
}
