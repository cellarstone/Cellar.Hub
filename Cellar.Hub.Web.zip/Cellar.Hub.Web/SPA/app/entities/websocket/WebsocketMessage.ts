export interface WebsocketMessage {
	name: string,
	data: any
}