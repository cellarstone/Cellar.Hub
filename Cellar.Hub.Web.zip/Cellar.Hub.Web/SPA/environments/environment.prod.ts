export const environment = {
    production: true,
    https: true
};
